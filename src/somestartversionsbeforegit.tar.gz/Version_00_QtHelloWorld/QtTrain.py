#!/usr/bin/env python

"""
QtTrain.py  - First code example, that creates a "Hallo world" Window GUI

Start work with Qt python GUI tutorials:
https://www.tutorialspoint.com/pyqt/pyqt_using_qt_designer.htm
Building of more complex interfaces needs graphical tools:
See project GitelufgGUI

"""

import sys
from PyQt4 import QtGui

def window():
  app = QtGui.QApplication(sys.argv)
  w = QtGui.QWidget()
  b = QtGui.QLabel(w)
  b.setText("Hello World!")
  w.setGeometry(100,100,200,50)
  b.move(50,20)
  w.setWindowTitle("PyQt")
  w.show()
  sys.exit(app.exec_())
	
if __name__ == '__main__':
  window()
