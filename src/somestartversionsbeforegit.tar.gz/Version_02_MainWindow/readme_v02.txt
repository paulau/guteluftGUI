To use more complex functionality, like "menu", it seems necessary to use 
"Main Window" wgich can be created using Qt Designer. Save it as 
glDesignMW.ui

run it:
pyuic4 -x  glDesignMW.ui -o glDesignMW.py
python glDesignMW.py

Analogously to creation of executable py file for Version_01_Form create gl.py file for main application
Then start it:

pyuic4   glDesignMW.ui -o glDesignMW.py
python gl.py

To train menu functionality, create menu with two points:

main  
  Save Image  - Save image to the file. 
  Send Feedback - Offers to send feedback message to Software developers.   
about - display message with Information "gl - Gute Luft Software. To view the data of airquality Sensors. 2018. Jade Hochschule."


Repeat functionality and labels of Version_01_Form in the application

It is not clear, how I generate Code of Events for menu elements. 
If I do it directly in glDesignMW.py then it will be lost, if I want in future to regenerate this file
from Qt Designer. 

!!!
???
One could inherite Object in derived new class and redefine methods, but now we leave this question for future. 

We proceed just with manual modification of glDesignMW.py to process onclick events of menu elements. 

Well, defining actions of submenu items works well outside of dlDesignMW.py
eg
    ui.actionProvide_feedback.triggered.connect(actionProvide_feedback) 
But not yet for menu items

We will live wit it now. Just add about submenu

custom text of functions of class: 

    def WindowActionTest(self):
        print ("Window Action Test")

Well glDesignMW.py is king of "header" file for the class. One can make new File 
glImplMW.py 
where the glDesignMW.py  will be simply included. 
Then in main program, can import things from  glImplMW.py  instead of importing them from Design file

keywords to solve problem inheritance composition dynamic code inclusion
InQt Designer two methods are added: 
after conversion into python the code must be inserted # private code below


#To approach us to something like more practical use of this excersise learning process we 
#will add matplotlib functionality to our Qt application
#
#in the training we see usage of one more widget layout

reading instructions of
https://stackoverflow.com/questions/12459811/how-to-embed-matplotlib-in-pyqt-for-dummies
it is done, 
however. so far without toolboxes, since example wants to have Form instead of main window. 
and also rando did not worked.






# private code
    def WindowActionTest(self):
        print ("Window Action Test")

    def WindowActionCombo(self):
        i = self.comboBox.currentIndex();
        smsg = self.comboBox.itemText(i)
        self.TestLabel.setText(_translate("MainWindow", smsg, None))

        pixmap = QtGui.QPixmap('test_IMG_20180109_103933.jpg')
        self.label_pic.setPixmap(pixmap) # it does not work well. but never mind first

        from matplotlib.backends.backend_qt4agg import FigureCanvasQTAgg as FigureCanvas
        from matplotlib.backends.backend_qt4agg import NavigationToolbar2QT as NavigationToolbar
        from matplotlib.figure import Figure

        #import random

        self.figure = Figure()

        # this is the Canvas Widget that displays the `figure`
        # it takes the `figure` instance as a parameter to __init__
        self.canvas = FigureCanvas(self.figure)

        # this is the Navigation widget
        # it takes the Canvas widget and a parent
     #   self.toolbar = NavigationToolbar("xx", self.canvas) #

        # set the layout

       # self.layout.addWidget(self.toolbar)
        self.layout.addWidget(self.canvas)
#        self.layout.addWidget(self.button)
      #  self.setLayout(layout)

        self.plot()



    def plot(self):
        ''' plot some random stuff '''
        # random data
#        data = [random.random() for i in range(10)]
        data = [i for i in range(10)]

        # create an axis
        ax = self.figure.add_subplot(111)

        # discards the old graph
        ax.clear()

        # plot data
        ax.plot(data, '*-')

        # refresh canvas
        self.canvas.draw()


