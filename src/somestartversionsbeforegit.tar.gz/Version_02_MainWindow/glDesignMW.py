# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'glDesignMW.ui'
#
# Created: Tue Jan  9 18:09:59 2018
#      by: PyQt4 UI code generator 4.11.2
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)

class Ui_MainWindow(object):
    def setupUi(self, MainWindow):
        MainWindow.setObjectName(_fromUtf8("MainWindow"))
        MainWindow.resize(800, 600)
        self.centralwidget = QtGui.QWidget(MainWindow)
        self.centralwidget.setObjectName(_fromUtf8("centralwidget"))
        self.pushButton = QtGui.QPushButton(self.centralwidget)
        self.pushButton.setGeometry(QtCore.QRect(120, 100, 100, 27))
        self.pushButton.setObjectName(_fromUtf8("pushButton"))
        self.comboBox = QtGui.QComboBox(self.centralwidget)
        self.comboBox.setGeometry(QtCore.QRect(30, 60, 191, 21))
        self.comboBox.setObjectName(_fromUtf8("comboBox"))
        self.comboBox.addItem(_fromUtf8(""))
        self.comboBox.addItem(_fromUtf8(""))
        self.comboBox.addItem(_fromUtf8(""))
        self.label_2 = QtGui.QLabel(self.centralwidget)
        self.label_2.setGeometry(QtCore.QRect(30, 40, 191, 16))
        font = QtGui.QFont()
        font.setFamily(_fromUtf8("Bitstream Charter"))
        font.setPointSize(10)
        font.setBold(True)
        font.setWeight(75)
        self.label_2.setFont(font)
        self.label_2.setObjectName(_fromUtf8("label_2"))
        self.label = QtGui.QLabel(self.centralwidget)
        self.label.setGeometry(QtCore.QRect(30, 10, 391, 16))
        font = QtGui.QFont()
        font.setFamily(_fromUtf8("Bitstream Charter"))
        font.setPointSize(10)
        font.setBold(True)
        font.setWeight(75)
        self.label.setFont(font)
        self.label.setObjectName(_fromUtf8("label"))
        self.TestLabel = QtGui.QLabel(self.centralwidget)
        self.TestLabel.setGeometry(QtCore.QRect(470, 50, 191, 18))
        self.TestLabel.setObjectName(_fromUtf8("TestLabel"))
        self.label_3 = QtGui.QLabel(self.centralwidget)
        self.label_3.setGeometry(QtCore.QRect(360, 50, 111, 18))
        self.label_3.setObjectName(_fromUtf8("label_3"))
        self.label_pic = QtGui.QLabel(self.centralwidget)
        self.label_pic.setGeometry(QtCore.QRect(360, 90, 381, 371))
        self.label_pic.setAutoFillBackground(False)
        self.label_pic.setStyleSheet(_fromUtf8("QLabel { background-color : white; }"))
        self.label_pic.setText(_fromUtf8(""))
        self.label_pic.setObjectName(_fromUtf8("label_pic"))
        self.verticalLayoutWidget = QtGui.QWidget(self.centralwidget)
        self.verticalLayoutWidget.setGeometry(QtCore.QRect(60, 180, 371, 341))
        self.verticalLayoutWidget.setObjectName(_fromUtf8("verticalLayoutWidget"))
        self.layout = QtGui.QVBoxLayout(self.verticalLayoutWidget)
        self.layout.setMargin(0)
        self.layout.setObjectName(_fromUtf8("layout"))
        MainWindow.setCentralWidget(self.centralwidget)
        self.menubar = QtGui.QMenuBar(MainWindow)
        self.menubar.setGeometry(QtCore.QRect(0, 0, 800, 28))
        self.menubar.setObjectName(_fromUtf8("menubar"))
        self.menuMain = QtGui.QMenu(self.menubar)
        self.menuMain.setObjectName(_fromUtf8("menuMain"))
        self.menuAbout = QtGui.QMenu(self.menubar)
        self.menuAbout.setObjectName(_fromUtf8("menuAbout"))
        MainWindow.setMenuBar(self.menubar)
        self.statusbar = QtGui.QStatusBar(MainWindow)
        self.statusbar.setObjectName(_fromUtf8("statusbar"))
        MainWindow.setStatusBar(self.statusbar)
        self.actionSave_Image = QtGui.QAction(MainWindow)
        self.actionSave_Image.setObjectName(_fromUtf8("actionSave_Image"))
        self.actionProvide_feedback = QtGui.QAction(MainWindow)
        self.actionProvide_feedback.setObjectName(_fromUtf8("actionProvide_feedback"))
        self.actionAbout = QtGui.QAction(MainWindow)
        self.actionAbout.setObjectName(_fromUtf8("actionAbout"))
        self.actionWindowActionTest = QtGui.QAction(MainWindow)
        self.actionWindowActionTest.setObjectName(_fromUtf8("actionWindowActionTest"))
        self.actionWindowActionCombo = QtGui.QAction(MainWindow)
        self.actionWindowActionCombo.setObjectName(_fromUtf8("actionWindowActionCombo"))
        self.menuMain.addAction(self.actionSave_Image)
        self.menuMain.addAction(self.actionProvide_feedback)
        self.menuAbout.addAction(self.actionAbout)
        self.menubar.addAction(self.menuMain.menuAction())
        self.menubar.addAction(self.menuAbout.menuAction())

        self.retranslateUi(MainWindow)
        QtCore.QMetaObject.connectSlotsByName(MainWindow)

    def retranslateUi(self, MainWindow):
        MainWindow.setWindowTitle(_translate("MainWindow", "guteluft.jade-hs.de", None))
        self.pushButton.setText(_translate("MainWindow", "Get help!", None))
        self.comboBox.setItemText(0, _translate("MainWindow", "H-I-07", None))
        self.comboBox.setItemText(1, _translate("MainWindow", "H-I-10", None))
        self.comboBox.setItemText(2, _translate("MainWindow", "H-I-21", None))
        self.label_2.setText(_translate("MainWindow", "Chose the room:", None))
        self.label.setText(_translate("MainWindow", "Application to view a data of guteluft.jade-hs.de", None))
        self.TestLabel.setText(_translate("MainWindow", "____", None))
        self.label_3.setText(_translate("MainWindow", "Chosen room:", None))
        self.menuMain.setTitle(_translate("MainWindow", "Main", None))
        self.menuAbout.setTitle(_translate("MainWindow", "About", None))
        self.actionSave_Image.setText(_translate("MainWindow", "Save Image", None))
        self.actionProvide_feedback.setText(_translate("MainWindow", "Provide feedback", None))
        self.actionAbout.setText(_translate("MainWindow", "About", None))
        self.actionWindowActionTest.setText(_translate("MainWindow", "WindowActionTest", None))
        self.actionWindowActionCombo.setText(_translate("MainWindow", "WindowActionCombo", None))


# private code
    def WindowActionTest(self):
        print ("Window Action Test")

    def WindowActionCombo(self):
        i = self.comboBox.currentIndex();
        smsg = self.comboBox.itemText(i)
        self.TestLabel.setText(_translate("MainWindow", smsg, None))

        pixmap = QtGui.QPixmap('test_IMG_20180109_103933.jpg')
        self.label_pic.setPixmap(pixmap) # it does not work well. but never mind first


#To approach us to something like more practical use of this excersise learning process we 
#will add matplotlib functionality to our Qt application
#
#in the training we see usage of one more widget layout

        from matplotlib.backends.backend_qt4agg import FigureCanvasQTAgg as FigureCanvas
        from matplotlib.backends.backend_qt4agg import NavigationToolbar2QT as NavigationToolbar
        from matplotlib.figure import Figure

        #import random

        self.figure = Figure()

        # this is the Canvas Widget that displays the `figure`
        # it takes the `figure` instance as a parameter to __init__
        self.canvas = FigureCanvas(self.figure)

        # this is the Navigation widget
        # it takes the Canvas widget and a parent
     #   self.toolbar = NavigationToolbar("xx", self.canvas) #

        # set the layout

       # self.layout.addWidget(self.toolbar)
        self.layout.addWidget(self.canvas)
#        self.layout.addWidget(self.button)
      #  self.setLayout(layout)

        self.plot()



    def plot(self):
        ''' plot some random stuff '''
        # random data
#        data = [random.random() for i in range(10)]
        data = [i for i in range(10)]

        # create an axis
        ax = self.figure.add_subplot(111)

        # discards the old graph
        ax.clear()

        # plot data
        ax.plot(data, '*-')

        # refresh canvas
        self.canvas.draw()


