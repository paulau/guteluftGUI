# -*- coding: utf-8 -*-

# This is just executable application, opening the Main Window glDesignMW
# https://www.tutorialspoint.com/pyqt/pyqt_multiple_document_interface.htm

import sys
from PyQt4 import QtCore, QtGui

from glDesignMW import *
from PyQt4.QtGui import *
from PyQt4.QtCore import *

# ============================================================================================================
# Menu Actions

def actionProvide_feedback():
    #This function will be implemented later
    msg = QMessageBox()
    msg.setIcon(QMessageBox.Information)
    msg.setText("It will be implemented later.")    
    msg.setStandardButtons(QMessageBox.Ok) #  | QMessageBox.Cancel #function displays desired buttons.
    retval = msg.exec_()

def actionAbout():
    #This function just shows About Info. 
    msg = QMessageBox()
    msg.setIcon(QMessageBox.Information)
    msg.setText("gl - Gute Luft Software. To view the data of airquality Sensors. 2018. Jade Hochschule.")    
    msg.setWindowTitle("About guteluft.jade-hs.de")
    msg.setStandardButtons(QMessageBox.Ok) #  | QMessageBox.Cancel #function displays desired buttons.
    retval = msg.exec_()

def actionAboutOne():
    #This function just shows About Info. 
    msg = QMessageBox()
    msg.setIcon(QMessageBox.Information)
    msg.setText("gl - Gute Luft Software. To view the data of airquality Sensors. 2018. Jade Hochschule.")    
    msg.setWindowTitle("About guteluft.jade-hs.de")
    msg.setStandardButtons(QMessageBox.Ok) #  | QMessageBox.Cancel #function displays desired buttons.
    retval = msg.exec_()



# ============================================================================================================
# Actions of Buttons ComboBox and other elements of the Window.

def HelpButton_clicked():
#    print "Help Button clicked"
    msg = QMessageBox()
    msg.setIcon(QMessageBox.Information)
    msg.setText("This program is created to visualise the data of airquality from the network of sensors of Jade Hochschule. The sensors are installed in different buildings in different rooms in Oldenburg(De). The room like H-I-21 means: H-Hauptgebäude, I-erste Obergeschoss(second floor), 21 - roomnumber. For detailed description of buildings, see Lageplan in guteluft.jade-hs.de")
    #msg.setInformativeText("This is additional information")
    msg.setWindowTitle("Help Message")
    #msg.setDetailedText("The details are as follows:")

    #function displays desired buttons.
    msg.setStandardButtons(QMessageBox.Ok) #  | QMessageBox.Cancel

    #msg.buttonClicked.connect(msgbtn)
    retval = msg.exec_()
    #print "value of pressed message box button:", retval

#A def actionCombo(): 
#A    # It gets argument - object MainWindow
#A    #This function process Choice of Room in the combobox.
#A    msg = QMessageBox()
#A    msg.setIcon(QMessageBox.Information)
#A    msg.setText("Test Now")    
#A    msg.setStandardButtons(QMessageBox.Ok) #  | QMessageBox.Cancel #function displays desired buttons.
#A    retval = msg.exec_()

# ============================================================================================================
# Main code:


if __name__ == "__main__":
    import sys
    app = QtGui.QApplication(sys.argv)
    MainWindow = QtGui.QMainWindow()

    ui = Ui_MainWindow()
    ui.setupUi(MainWindow)

    ui.pushButton.clicked.connect(HelpButton_clicked) # connect onclick event of button with according function
    ui.actionProvide_feedback.triggered.connect(actionProvide_feedback) 
    
    # Define Submenu Action for actionAbout
    #ui.actionAbout.triggered.connect(actionAbout) 
    #or so:
    QtCore.QObject.connect(ui.actionAbout, QtCore.SIGNAL("triggered()"), actionAbout) 


    # attemt to redefine action for menu point ! Not Submenu!
    #QtCore.QObject.connect(ui.menuAbout, QtCore.SIGNAL("activated()"), ui.WindowActionTest)  #it does not make what I want
    #ui.menuAbout.triggered[QAction].connect(xxx) # does not work
    
    #A ui.comboBox.currentIndexChanged.connect(actionCombo) #
    
    # Well The following method is defined in glDesignMW.py itself. Hence It will disappear after each regenerate of file
    ui.actionSave_Image.triggered.connect(ui.WindowActionTest) #

    ui.comboBox.currentIndexChanged.connect(ui.WindowActionCombo) #

    #ui.menuAbout.triggered.connect(actionProvide_feedback) 
 
    MainWindow.show()
    sys.exit(app.exec_())

