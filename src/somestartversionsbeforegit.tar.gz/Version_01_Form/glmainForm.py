# -*- coding: utf-8 -*-

# This is just executable application, opening the form glFormDesign

import sys
from PyQt4 import QtCore, QtGui

from glFormDesign import *
from PyQt4.QtGui import *
from PyQt4.QtCore import *

def HelpButton_clicked():
#    print "Help Button clicked"
    msg = QMessageBox()
    msg.setIcon(QMessageBox.Information)
    msg.setText("This program is created to visualise the data of airquality from the network of sensors of Jade Hochschule. The sensors are installed in different buildings in different rooms in Oldenburg(De). The room like H-I-21 means: H-Hauptgebäude, I-erste Obergeschoss(second floor), 21 - roomnumber. For detailed description of buildings, see Lageplan in guteluft.jade-hs.de")
    #msg.setInformativeText("This is additional information")
    msg.setWindowTitle("Help Message")
  #  msg.setDetailedText("The details are as follows:")

  # function displays desired buttons.
    msg.setStandardButtons(QMessageBox.Ok) #  | QMessageBox.Cancel

    #msg.buttonClicked.connect(msgbtn)
    retval = msg.exec_()
    print "value of pressed message box button:", retval

#def msgbtn(i):
#    print "Button pressed is:",i.text()

if __name__ == "__main__":
    
    app = QtGui.QApplication(sys.argv)
    Form = QtGui.QWidget()

    ui = Ui_Form()
    ui.setupUi(Form)

#    bar = app.menuBar()

    ui.pushButton.clicked.connect(HelpButton_clicked) # connect onclick event of button with according function


    Form.show()
    sys.exit(app.exec_())

